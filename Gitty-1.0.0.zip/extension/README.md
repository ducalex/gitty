# Gitty
Although this project is original, it is heavily inspired by https://github.com/huizhougit/githd 
and shamelessly copied some of its style and icons.
